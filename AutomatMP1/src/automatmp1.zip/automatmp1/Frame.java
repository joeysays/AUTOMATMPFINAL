/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package automatmp1;

import java.util.ArrayList;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Image;
import javax.swing.JPanel;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.ImageIcon;


import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 *
 * @author Belle
 */
public class Frame extends javax.swing.JFrame {
    public Container pane;
    JPanel jp1 = new JPanel();
    JPanel jp2 = new JPanel();
    StatePanel s1 = new StatePanel();
    StatePanel s2 = new StatePanel();
    StatePanel s3 = new StatePanel();
    StatePanel s4 = new StatePanel();
    StatePanel s5 = new StatePanel();
    StatePanel s6 = new StatePanel();
    StatePanel s7 = new StatePanel();
    StatePanel s8 = new StatePanel();
    StatePanel s9 = new StatePanel();
    StatePanel s10 = new StatePanel();
    StatePanel s11 = new StatePanel();
    StatePanel s12 = new StatePanel();
    StatePanel s13 = new StatePanel();
    StatePanel s14 = new StatePanel();
    StatePanel s15 = new StatePanel();
    StatePanel s16 = new StatePanel();
//    LinePanel lp1 = new LinePanel();
//    LinePanel lp2 = new LinePanel();
//    LinePanel lp3 = new LinePanel();
//    LinePanel lp4 = new LinePanel();
//    LinePanel lp5 = new LinePanel();
//    LinePanel lp6 = new LinePanel();
//    LinePanel lp7 = new LinePanel();
//    LinePanel lp8 = new LinePanel();
//    LinePanel1 lp9 = new LinePanel1();
//    LinePanel1 lp10 = new LinePanel1();
//    LinePanel2 lp11 = new LinePanel2();
//    LinePanel lp12 = new LinePanel();
//    LinePanel lp13 = new LinePanel();
//    LinePanel lp14 = new LinePanel();
//    LinePanel lp15 = new LinePanel();
//    LinePanel lp16 = new LinePanel();
//    LinePanel lp17 = new LinePanel();
//    LinePanel lp18 = new LinePanel();
//    LinePanel lp19 = new LinePanel();
//    LinePanel lp20 = new LinePanel();
//    LinePanel lp21 = new LinePanel();
//    LinePanel lp22 = new LinePanel();
//    LinePanel lp23 = new LinePanel();

    
    
	
    Formatter formatter = new Formatter();
    
   
    Planet earth = new Planet();
    Planet mars = new Planet();
    
    DefaultListModel dm = new DefaultListModel();
    DefaultListModel dm1 = new DefaultListModel();
    DefaultListModel dm2 = new DefaultListModel();
    Entity s = new Entity("Scientist", "Earth");
    Entity c = new Entity("Cow", "Earth");
    Entity l = new Entity("Lion", "Earth");
    Entity g = new Entity("Grains", "Earth");
    Entity h1 = new Entity("Human 1", "Earth");
    Entity h2 = new Entity("Human 2", "Earth");
    Entity e = new Entity("Scientist", "Earth");
    int m = 0;
    
    /**
     * Creates new form Frame
     */
    
    public Frame() {
        initComponents();
        setTitle("Automat MP");
        
        earth.addOccupant(s.name);
        earth.addOccupant(c.name);
        earth.addOccupant(l.name);
        earth.addOccupant(g.name);
        earth.addOccupant(h1.name);
        earth.addOccupant(h2.name);
        earth.addOccupant(e.name);
        
        jList1.setModel(dm);
        dm.addElement(s.name);
        dm.addElement(c.name);
        dm.addElement(l.name);
        dm.addElement(g.name);
        dm.addElement(h1.name);
        dm.addElement(h2.name);
        s1.setBounds(0, 500, 20, 20);
        s2.setBounds(100, 500, 20, 20);
        s3.setBounds(200, 500, 20, 20);
        s4.setBounds(300, 500, 20, 20);
        s5.setBounds(400, 500, 20, 20);
        s6.setBounds(500, 500, 20, 20);
        s7.setBounds(600, 500, 20, 20);
        s8.setBounds(700, 500, 20, 20);
        s9.setBounds(200, 400, 20, 20);
        s10.setBounds(200, 300, 20, 20);
        s11.setBounds(200, 200, 20, 20);
        s12.setBounds(0, 300, 20, 20);
        s13.setBounds(350, 270, 20, 20);
        s14.setBounds(450, 400, 20, 20);
        s15.setBounds(550, 450, 20, 20);
        s16.setBounds(700, 270, 20, 20);
//        lp1.setBounds(20, 507, 70, 50);
//        lp2.setBounds(120, 507, 70, 50);
//        lp3.setBounds(220, 507, 70, 50);
//        lp4.setBounds(320, 507, 70, 50);
//        lp5.setBounds(420, 507, 70, 50);
//        lp6.setBounds(520, 507, 70, 50);
//        lp7.setBounds(620, 507, 70, 50);
//        lp8.setBounds(370, 277, 450, 50);
//        lp9.setBounds(10, 310, 190, 300);
//        lp10.setBounds(210, 210, 130, 300);
//        lp11.setBounds()
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
    	setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    	setSize(1650,1000);

        sButton = new javax.swing.JButton();
        cButton = new javax.swing.JButton();
        lButton = new javax.swing.JButton();
        gButton = new javax.swing.JButton();
        h1Button = new javax.swing.JButton();
        h2Button = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        goButton = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        jList2 = new javax.swing.JList<>();
        jScrollPane5 = new javax.swing.JScrollPane();
        jList3 = new javax.swing.JList<>();
        clrButton = new javax.swing.JButton();
        resetButton = new javax.swing.JButton();
        messageTA = new javax.swing.JTextArea();
        jScrollPaneTA = new javax.swing.JScrollPane(messageTA);
        movesLbl = new javax.swing.JLabel();

       // sButton.setText("Scientist");
        sButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sButtonActionPerformed(evt);
            }
        });

        //cButton.setText("Cow");
        cButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cButtonActionPerformed(evt);
            }
        });

        //lButton.setText("Lion");
        lButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lButtonActionPerformed(evt);
            }
        });

        //gButton.setText("Grain");
        gButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gButtonActionPerformed(evt);
            }
        });

        //h1Button.setText("Human 1");
        h1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                h1ButtonActionPerformed(evt);
            }
        });

        //h2Button.setText("Human 2");
        h2Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                h2ButtonActionPerformed(evt);
            }
        });

        jLabel1.setText("Earth");

        jLabel2.setText("Mars");
        
        movesLbl.setText("Moves: 0");

        jScrollPane3.setViewportView(jList1);

        jScrollPane4.setViewportView(jList2);

        jScrollPane5.setViewportView(jList3);
        
       // goButton.setText("Go");
        goButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                goButtonActionPerformed(evt);
            }
        });

        clrButton.setText("CLEAR");
        clrButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clrButtonActionPerformed(evt);
            }
        });
        
        resetButton.setText("RESET");
        resetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetButtonActionPerformed(evt);
            }
        });
        

		pane = getContentPane();
		pane.setLayout(new BoxLayout(pane, BoxLayout.X_AXIS));

		jp1.setPreferredSize(new Dimension(550, 700));
		jp1.setMaximumSize(jp1.getPreferredSize()); 
		jp1.setMinimumSize(jp1.getPreferredSize());
		jp1.setLayout(null);

		jp2.setPreferredSize(new Dimension(1000, 700));
		jp2.setMaximumSize(jp2.getPreferredSize()); 
		jp2.setMinimumSize(jp2.getPreferredSize());
		jp2.setLayout(null);
		
		pane.add(jp1);
		pane.add(jp2);
		
		jp2.add(s1);
		jp2.add(s2);
		jp2.add(s3);
		jp2.add(s4);
		jp2.add(s5);
		jp2.add(s6);
		jp2.add(s7);
		jp2.add(s8);
		jp2.add(s9);
		jp2.add(s10);
		jp2.add(s11);
		jp2.add(s12);
		jp2.add(s13);
		jp2.add(s14);
		jp2.add(s15);
		jp2.add(s16);
//		jp2.add(lp1);
//		jp2.add(lp2);
//		jp2.add(lp3);
//		jp2.add(lp4);
//		jp2.add(lp5);
//		jp2.add(lp6);
//		jp2.add(lp7);
//		jp2.add(lp8);
//		jp2.add(lp9);
//		jp2.add(lp10);
//		jp2.add(lp11);
//		jp2.add(lp12);
//		jp2.add(lp13);
//		jp2.add(lp14);
//		jp2.add(lp15);
//		jp2.add(lp16);
//		jp2.add(lp17);
//		jp2.add(lp18);
//		jp2.add(lp19);
//		jp2.add(lp20);
//		jp2.add(lp21);
//		jp2.add(lp22);
//		jp2.add(lp23);

		//s1.setBound(100, 100, 50, 50);

		
		//jp2.drawOval(100, 100, 80,80);
		
		
		
		jp1.add(jLabel1); // earth
		jLabel1.setBounds(100, 30, 50, 50);
		
		jp1.add(jLabel2); // mars
		jLabel2.setBounds(360, 30, 50, 50);
		
		jp1.add(movesLbl);
		movesLbl.setBounds(305, 250, 50, 50);
		
		jp1.add(jList1); 
		jList1.setBounds(70, 80, 100, 150);
		
		jp1.add(jList2);
		jList2.setBounds(200, 80, 100, 150);
  
		jp1.add(jList3);
		jList3.setBounds(330, 80, 100, 150);
		
		jp1.add(messageTA);
		messageTA.setEditable(false);
		messageTA.setBounds(300, 580, 170, 50);
		
		
		
		goButton.setBounds(300, 300, 80, 80);
		ImageIcon goImage = new ImageIcon("C:\\Users\\Belle\\Documents\\GitHub\\automat\\AutomatMP1\\src\\images\\go.png");
		Image goImg = goImage.getImage();
		Image newGoImg = goImg.getScaledInstance(goButton.getWidth(), goButton.getHeight(), Image.SCALE_SMOOTH); //this makes the image fit the button
		ImageIcon goImageIcon = new ImageIcon(newGoImg);
		goButton.setIcon(goImageIcon);
		jp1.add(goButton);
		validate();

		goButton.setOpaque(false);
		goButton.setContentAreaFilled(false);
		goButton.setBorderPainted(false);

		jp1.add(clrButton);
		clrButton.setBounds(300, 390, 80, 80);
		
		jp1.add(resetButton);
		resetButton.setBounds(300, 480, 80, 80);
		
		sButton.setBounds(70, 270, 80, 80);
		ImageIcon sImage = new ImageIcon("C:\\Users\\Belle\\Documents\\GitHub\\automat\\AutomatMP1\\src\\images\\scientist.png");
		Image sImg = sImage.getImage();
		Image newSImg = sImg.getScaledInstance(sButton.getWidth(), sButton.getHeight(), Image.SCALE_SMOOTH); //this makes the image fit the button
		ImageIcon sImageIcon = new ImageIcon(newSImg);
		sButton.setIcon(sImageIcon);
		jp1.add(sButton);
		validate();
		
		cButton.setBounds(70, 360, 80, 80);
		ImageIcon cImage = new ImageIcon("C:\\Users\\Belle\\Documents\\GitHub\\automat\\AutomatMP1\\src\\images\\Cow.png");
		Image cImg = cImage.getImage();
		Image newCImg = cImg.getScaledInstance(cButton.getWidth(), cButton.getHeight(), Image.SCALE_SMOOTH); //this makes the image fit the button
		ImageIcon cImageIcon = new ImageIcon(newCImg);
		cButton.setIcon(cImageIcon);
		jp1.add(cButton);
		validate();
		
		lButton.setBounds(70, 450, 80, 80);
		ImageIcon lImage = new ImageIcon("C:\\Users\\Belle\\Documents\\GitHub\\automat\\AutomatMP1\\src\\images\\Lion.png");
		Image lImg = lImage.getImage();
		Image newLImg = lImg.getScaledInstance(lButton.getWidth(), lButton.getHeight(), Image.SCALE_SMOOTH); //this makes the image fit the button
		ImageIcon lImageIcon = new ImageIcon(newLImg);
		lButton.setIcon(lImageIcon);
		jp1.add(lButton);
		validate();
		
		gButton.setBounds(170, 270, 80, 80);
		ImageIcon gImage = new ImageIcon("C:\\Users\\Belle\\Documents\\GitHub\\automat\\AutomatMP1\\src\\images\\Grains.png");
		Image gImg = gImage.getImage();
		Image newGImg = gImg.getScaledInstance(gButton.getWidth(), gButton.getHeight(), Image.SCALE_SMOOTH); //this makes the image fit the button
		ImageIcon gImageIcon = new ImageIcon(newGImg);
		gButton.setIcon(gImageIcon);
		jp1.add(gButton);
		validate();
		
		h1Button.setBounds(170, 360, 80, 80);
		ImageIcon h1Image = new ImageIcon("C:\\Users\\Belle\\Documents\\GitHub\\automat\\AutomatMP1\\src\\images\\Human1.png");
		Image h1Img = h1Image.getImage();
		Image newH1Img = h1Img.getScaledInstance(h1Button.getWidth(), h1Button.getHeight(), Image.SCALE_SMOOTH); //this makes the image fit the button
		ImageIcon h1ImageIcon = new ImageIcon(newH1Img);
		h1Button.setIcon(h1ImageIcon);
		jp1.add(h1Button);
		validate();

		
		h2Button.setBounds(170, 450, 80, 80);
		ImageIcon h2Image = new ImageIcon("C:\\Users\\Belle\\Documents\\GitHub\\automat\\AutomatMP1\\src\\images\\Human2.png");
		Image h2Img = h2Image.getImage();
		Image newH2Img = h2Img.getScaledInstance(h2Button.getWidth(), h2Button.getHeight(), Image.SCALE_SMOOTH); //this makes the image fit the button
		ImageIcon h2ImageIcon = new ImageIcon(newH2Img);
		h2Button.setIcon(h2ImageIcon);
		jp1.add(h2Button);
		validate();
		
		

    }// </editor-fold>//GEN-END:initComponents

    private void sButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sButtonActionPerformed
        // TODO add your handling code here:
    //    formatter.appendToPane(jTextPane1, e.name, Color.blue);
        jList1.setModel(dm);
        jList2.setModel(dm1);
        jList3.setModel(dm2);
        
        if(dm1.size() < 3){
            dm1.addElement(s.name);
        }

        if(dm1.size() == 3)
        {
            h2Button.setEnabled(false);
            cButton.setEnabled(false);
            lButton.setEnabled(false);
            gButton.setEnabled(false);
            h1Button.setEnabled(false);
        }
        
        sButton.setEnabled(false);
    }//GEN-LAST:event_sButtonActionPerformed

    private void lButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lButtonActionPerformed
        // TODO add your handling code here:
        jList1.setModel(dm);
        jList2.setModel(dm1);
        jList3.setModel(dm2);
        
        if(dm1.size() < 3){
            dm1.addElement(l.name);
        }
        
        if(dm1.size() == 3)
        {
            sButton.setEnabled(false);
            cButton.setEnabled(false);
            h2Button.setEnabled(false);
            gButton.setEnabled(false);
            h1Button.setEnabled(false);
        }
        
        
        lButton.setEnabled(false);
    }//GEN-LAST:event_lButtonActionPerformed

    private void cButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cButtonActionPerformed
        // TODO add your handling code here:
        jList1.setModel(dm);
        jList2.setModel(dm1);
        jList3.setModel(dm2);
        
        if(dm1.size() < 3){
            dm1.addElement(c.name);
        }
        
        if(dm1.size() == 3)
        {
            sButton.setEnabled(false);
            h2Button.setEnabled(false);
            lButton.setEnabled(false);
            gButton.setEnabled(false);
            h1Button.setEnabled(false);
        }
        
        
        cButton.setEnabled(false);
    }//GEN-LAST:event_cButtonActionPerformed

    private void gButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gButtonActionPerformed
        // TODO add your handling code here:
        jList1.setModel(dm);
        jList2.setModel(dm1);
        jList3.setModel(dm2);
        
        if(dm1.size() < 3){
            dm1.addElement(g.name);
        }

        if(dm1.size() == 3)
        {
            sButton.setEnabled(false);
            cButton.setEnabled(false);
            lButton.setEnabled(false);
            h1Button.setEnabled(false);
            h2Button.setEnabled(false);
        }
        
        gButton.setEnabled(false);
    }//GEN-LAST:event_gButtonActionPerformed

    private void h1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_h1ButtonActionPerformed
        // TODO add your handling code here:
        jList1.setModel(dm);
        jList2.setModel(dm1);
        jList3.setModel(dm2);
        
        if(dm1.size() < 3){
            dm1.addElement(h1.name);
        }
        
        if(dm1.size() == 3)
        {
            sButton.setEnabled(false);
            cButton.setEnabled(false);
            lButton.setEnabled(false);
            gButton.setEnabled(false);
            h2Button.setEnabled(false);
        }
        
        
        h1Button.setEnabled(false);
    }//GEN-LAST:event_h1ButtonActionPerformed

    private void h2ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_h2ButtonActionPerformed
        // TODO add your handling code here:
        jList1.setModel(dm);
        jList2.setModel(dm1);
        jList3.setModel(dm2);
        
        if(dm1.size() < 3){
            dm1.addElement(h2.name);
        }
        
        
        if(dm1.size() == 3)
        {
            sButton.setEnabled(false);
            cButton.setEnabled(false);
            lButton.setEnabled(false);
            gButton.setEnabled(false);
            h1Button.setEnabled(false);
        }
        
        h2Button.setEnabled(false);
    }//GEN-LAST:event_h2ButtonActionPerformed

    private void goButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_goButtonActionPerformed
        // TODO add your handling code here:
        jList1.setModel(dm);
        jList2.setModel(dm1);
        jList3.setModel(dm2);
        int c = 0;
        
        
        
        int g = 0;
        String message = new String();
        
        for(int i = 0; i < dm1.size(); i++){
            if(dm1.get(i).equals("Scientist")){
                g = 1;
            }
        }
        System.out.println("g = " + g);

        if(g == 1){ //only if the scientist exists 	
            if(m % 2 == 0){  //if coming from earth to mars
                
                for(int j = 0; j < dm1.size(); j++){ //removes from earth(dm)
             	   System.out.println("Middle[" + j + "] = " + dm1.get(j));
             	   
             	   for(int i = 0; i < dm.size(); i++) {
 	            	   if(dm.get(i).equals(dm1.get(j)))
 	            	   {
 	            		   earth.removeOccupant(dm1.get(j).toString());
 	            		   dm.removeElement(dm1.get(j));
 	            	   }
             	   }       
                 }

                for(int i = 0; i < dm1.size(); i++){ //adds to dm2(mars)
                    dm2.addElement(dm1.get(i));
                    mars.addOccupant(dm1.get(i).toString());
                }
                for(int i = 0; i < 3; i++){ //removes from middle(dm1)
                    if(dm1.size() > 0){
                        dm1.removeElement(dm1.get(0));
                    }
                }
                m = m + 1;
                movesLbl.setText("Moves: " + m);
                
                System.out.println("*****************Number of occupants on earth: " + earth.getOccupants().size());
            }
            
            else{ //if coming from mars to earth  
               System.out.println("SIZEE: " + dm1.size());
               for(int j = 0; j < dm1.size(); j++){ //removes from mars(dm2)
            	   System.out.println("Middle[" + j + "] = " + dm1.get(j));
            	   
            	   for(int i = 0; i < dm2.size(); i++) {
	            	   if(dm2.get(i).equals(dm1.get(j)))
	            	   {
	            		   mars.removeOccupant(dm1.get(j).toString());
	            		   dm2.removeElement(dm1.get(j));
	            	   }
            	   }       
                }
               
               for(int i = 0; i < dm1.size(); i++){ //adds to earth(dm)
                    dm.addElement(dm1.get(i));
                    earth.addOccupant(dm1.get(i).toString());
                }
               
               for(int i = 0; i < 3; i++){  //removes from middle(dm1)
                   if(dm1.size() > 0){
                        dm1.removeElement(dm1.get(0));
                   }
                }
               
               m = m + 1;
               movesLbl.setText("Moves: " + m);
            }
            
            //print current occupants of each planet
        	System.out.println("EARTH'S OCCUPANTS: ");
        	for(int i = 0; i < earth.getOccupants().size(); i++)
        	{
        		System.out.println(earth.getOccupants().get(i));
        	}
        	
        	System.out.println();
        	System.out.println("MARS' OCCUPANTS: ");
        	for(int i = 0; i < mars.getOccupants().size(); i++)
        	{
        		System.out.println(mars.getOccupants().get(i));
        	}
            
            //check if anyone was eaten
            if(earth.check().equals("valid") && mars.check().equals("valid"))
            {
            	System.out.println("Everyone is still OK.");
            	message = "Everyone is still OK.";
            	messageTA.setText(message);
            }
            else {
            	System.out.println("Someone was eaten :(");  
            	
            	if(!(earth.check().equals("valid")))
            	{
            		message = earth.check();
            		messageTA.setText(message);
            	}
            	else if(!(mars.check().equals("valid")))
	            	{
	            		message = mars.check();
	            		messageTA.setText(message);
	            	}
            }
        }
        else {
        	System.out.println("The scientist must be present to travel!");
    		message = "The scientist must be \npresent to travel!";
    		messageTA.setText(message);
        }
        
        sButton.setEnabled(true);
        cButton.setEnabled(true);
        lButton.setEnabled(true);
        gButton.setEnabled(true);
        h1Button.setEnabled(true);
        h2Button.setEnabled(true);
        
        if(earth.getOccupants().isEmpty())
        {
        	messageTA.setText("CONGRATS! Everyone made\n it to Mars safely :)");
                sButton.setEnabled(false);
                cButton.setEnabled(false);
                lButton.setEnabled(false);
                gButton.setEnabled(false);
                h1Button.setEnabled(false);
                h2Button.setEnabled(false);
        }
        
        
        if(m % 2 == 0){
            for(int i = 0; i < dm.size(); i++){
                if(!(dm.get(i).equals("Lion"))){
                    c = c + 1;
                }
            }
            if(c == dm.getSize()){
                lButton.setEnabled(false);
            }
            c = 0;
            for(int i = 0; i < dm.size(); i++){
                if(!(dm.get(i).equals("Cow"))){
                    c = c + 1;
                }
            }
            if(c == dm.getSize()){
                cButton.setEnabled(false);
            }
            c = 0;
            for(int i = 0; i < dm.size(); i++){
                if(!(dm.get(i).equals("Grains"))){
                    c = c + 1;
                }
            }
            if(c == dm.getSize()){
                gButton.setEnabled(false);
            }
            c = 0;
            for(int i = 0; i < dm.size(); i++){
                if(!(dm.get(i).equals("Human 1"))){
                    c = c + 1;
                }
            }
            if(c == dm.getSize()){
                h1Button.setEnabled(false);
            }
            c = 0;
            for(int i = 0; i < dm.size(); i++){
                if(!(dm.get(i).equals("Human 2"))){
                    c = c + 1;
                }
            }
            if(c == dm.getSize()){
                h2Button.setEnabled(false);
            }
            c = 0;
        }
        else{
            for(int i = 0; i < dm.size(); i++){
                if(!(dm2.get(i).equals("Lion"))){
                    c = c + 1;
                }
            }
            if(c == dm2.getSize()){
                lButton.setEnabled(false);
            }
            c = 0;
            for(int i = 0; i < dm.size(); i++){
                if(!(dm2.get(i).equals("Cow"))){
                    c = c + 1;
                }
            }
            if(c == dm2.getSize()){
                cButton.setEnabled(false);
            }
            c = 0;
            for(int i = 0; i < dm.size(); i++){
                if(!(dm2.get(i).equals("Grains"))){
                    c = c + 1;
                }
            }
            if(c == dm2.getSize()){
                gButton.setEnabled(false);
            }
            c = 0;
            for(int i = 0; i < dm.size(); i++){
                if(!(dm2.get(i).equals("Human 1"))){
                    c = c + 1;
                }
            }
            if(c == dm2.getSize()){
                h1Button.setEnabled(false);
            }
            c = 0;
            for(int i = 0; i < dm.size(); i++){
                if(!(dm2.get(i).equals("Human 2"))){
                    c = c + 1;
                }
            }
            if(c == dm2.getSize()){
                h2Button.setEnabled(false);
            }
            c = 0;
        }
        System.out.println("C = " + c);
    }//GEN-LAST:event_goButtonActionPerformed

    private void clrButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clrButtonActionPerformed
        // TODO add your handling code here:
        dm1.removeAllElements();
        
        jList1.setModel(dm);
        jList2.setModel(dm1);
        jList3.setModel(dm2);
        
        sButton.setEnabled(true);
        cButton.setEnabled(true);
        lButton.setEnabled(true);
        gButton.setEnabled(true);
        h1Button.setEnabled(true);
        h2Button.setEnabled(true);
        
    }//GEN-LAST:event_clrButtonActionPerformed

    //reset moves to 0, clear all JLists, move everything back to earth
    private void resetButtonActionPerformed(java.awt.event.ActionEvent evt) {
    	m = 0;
    	movesLbl.setText("Moves: " + m);
        sButton.setEnabled(true);
        cButton.setEnabled(true);
        lButton.setEnabled(true);
        gButton.setEnabled(true);
        h1Button.setEnabled(true);
        h2Button.setEnabled(true);
        
        earth.addOccupant(s.name);
        earth.addOccupant(c.name);
        earth.addOccupant(l.name);
        earth.addOccupant(g.name);
        earth.addOccupant(h1.name);
        earth.addOccupant(h2.name);
        earth.addOccupant(e.name);
        
        mars.removeAllOccupants();
        
    	dm.removeAllElements();
    	dm1.removeAllElements();
    	dm2.removeAllElements();
        
        dm.addElement(s.name);
        dm.addElement(c.name);
        dm.addElement(l.name);
        dm.addElement(g.name);
        dm.addElement(h1.name);
        dm.addElement(h2.name);
        
        jList1.setModel(dm);
        jList2.setModel(dm1);
        jList3.setModel(dm2);
        
        messageTA.setText("");
    	
    }
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        //Graphics g = new Graphics();
       
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            //    Frame f = new Frame().setVisible(true);
		
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cButton;
    private javax.swing.JButton clrButton;
    private javax.swing.JButton gButton;
    private javax.swing.JButton goButton;
    private javax.swing.JButton resetButton;
    private javax.swing.JButton h1Button;
    private javax.swing.JButton h2Button;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JList<String> jList1;
    private javax.swing.JList<String> jList2;
    private javax.swing.JList<String> jList3;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JButton lButton;
    private javax.swing.JButton sButton;
    private javax.swing.JTextArea messageTA;
    private javax.swing.JLabel movesLbl;
    private javax.swing.JScrollPane jScrollPaneTA;
    // End of variables declaration//GEN-END:variables
}
